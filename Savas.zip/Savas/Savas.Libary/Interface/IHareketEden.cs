﻿/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/


using Savas.Libary.Enum;
using System.Drawing;
namespace Savas.Libary.Interface
{
    internal interface IHareketEden
    {
        Size HareketAlaniBoyutlari { get;  }

        int HareketMesafesi { get;  }

    
        /// <summary>
        /// Cismi istenilen yöne Hareket Ettirir
        /// </summary>
        /// <param name="yon"> Hangi yöne hareket ettirilieceği </param>
        /// <returns>Cisim duavra çarparsa true döndür.</returns>
        bool HareketEttir(Yon yon);
    }
}
