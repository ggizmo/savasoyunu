﻿/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/



using System;
using Savas.Libary.Enum;



namespace Savas.Libary.arayüz_int_
{
    internal interface IOyun
    {

        event EventHandler GecenSureDegisti;
        bool DevamEdiyorMu { get; } 
        TimeSpan GecenSure { get; }
        void Baslat();
        void AtesEt();
        void UcaksavariHareketEttir(Yon yon);

        void Durdur();
        void DevamEttir();
    }
   
}
