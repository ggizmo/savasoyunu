﻿/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/




using Savas.Libary.Abstract;
using System.Drawing;
using System.Windows.Forms;

namespace Savas.Libary.Concrete
{
    internal class Ucaksavar : Cisim
    {
      public Ucaksavar(int panelGenisligi, Size hareketAlaniBoyutlari) : base(hareketAlaniBoyutlari)
        {

            Center = panelGenisligi / 2;
            HareketMesafesi = Width;
            
        }
    }
}
