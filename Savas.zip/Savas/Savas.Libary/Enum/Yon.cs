﻿/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/



namespace Savas.Libary.Enum
{
   public enum Yon

{
    Yukari,
    Saga,
    Asagi,
    Sola,
}

}
