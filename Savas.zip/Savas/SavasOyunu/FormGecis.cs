﻿using System;

namespace SavasOyunu
{
    internal class OyunEkrani
    {
        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}