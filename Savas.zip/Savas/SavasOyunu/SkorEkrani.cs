﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/


namespace SavasOyunu
{
    public partial class Skor_Ekranı : Form
    {
        public Skor_Ekranı()
        {
            InitializeComponent();
        }

      


        private void Skor_Ekranı_Load(object sender, EventArgs e)
        {

        }

        private void skorlabel2_Click(object sender, EventArgs e)
        {

        }
    }
    }

