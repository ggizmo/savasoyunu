﻿
namespace SavasOyunu
{
    partial class Skor_Ekranı
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Skor_Ekranı));
            this.skorlabel2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // skorlabel2
            // 
            this.skorlabel2.AutoSize = true;
            this.skorlabel2.Font = new System.Drawing.Font("Ravie", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skorlabel2.Location = new System.Drawing.Point(281, 74);
            this.skorlabel2.Name = "skorlabel2";
            this.skorlabel2.Size = new System.Drawing.Size(236, 34);
            this.skorlabel2.TabIndex = 0;
            this.skorlabel2.Text = "SKOR EKRANI";
            this.skorlabel2.Click += new System.EventHandler(this.skorlabel2_Click);
            // 
            // Skor_Ekranı
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.skorlabel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Skor_Ekranı";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Skor Ekranı";
            this.Load += new System.EventHandler(this.Skor_Ekranı_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label skorlabel2;
    }
}