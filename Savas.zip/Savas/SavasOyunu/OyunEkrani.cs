﻿/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/


using System;
using System.Windows.Forms;
using Savas.Libary.Concrete;
using Savas.Libary.Enum;



namespace Oyun
{
    public partial class AnaForm : Form
    {

        private readonly Oyunu _oyunu;
        public AnaForm()
        {
            InitializeComponent();

            _oyunu = new Oyunu(ucaksavarPanel, savasAlaniPanel);

            _oyunu.GecenSureDegisti += Oyunu_GecenSureDegisti;

        }


        public void AnaForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    _oyunu.Baslat();
                    break;
                case Keys.Right:
                    _oyunu.UcaksavariHareketEttir(Yon.Saga);
                    break;
                case Keys.Left:
                    _oyunu.UcaksavariHareketEttir(Yon.Sola);
                    break;
                case Keys.Space:
                    _oyunu.AtesEt();
                    break;
                case Keys.CapsLock:
                    _oyunu.Durdur();
                    break;
                case Keys.Tab:
                    _oyunu.DevamEttir();
                    break;


            }
        }

        private void Oyunu_GecenSureDegisti(object sender, EventArgs e)
        {
            sureLabel.Text = $"{_oyunu.GecenSure.Minutes}:{_oyunu.GecenSure.Seconds.ToString("D2")}";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Oyunalanı_Paint(object sender, PaintEventArgs e)
        {

        }

        private void sayaç_Click(object sender, EventArgs e)
        {

        }

        private void bilgipaneli_Paint(object sender, PaintEventArgs e)
        {

        }

        
        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
