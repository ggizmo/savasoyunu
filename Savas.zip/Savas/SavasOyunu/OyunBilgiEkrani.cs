﻿using System;
using Oyun;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/



using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SavasOyunu
{
    public partial class OyunBilgiEkrani : Form
    {
        public OyunBilgiEkrani()
        {
            InitializeComponent();
        }
        private void OyunBilgiEkrani_Load(object sender, EventArgs e)
        {

        }

        private void OyunBaslat_Click(object sender, EventArgs e)
        {
            AnaForm anaform = new AnaForm();
            anaform.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Bilgi_Click(object sender, EventArgs e)
        {

        }
    }
}
