﻿using Oyun;
/**************SAKARYA ÜNİVERSİTESİ *****************
 ******BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ*****
 ********BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ*************
 ************ÖĞRENCİ ADI: GİZEM TOPRAK***************
 ************ÖĞRENCİ NUMARASI: B191200030************
 *******DERSİN ADI: NESNE DAYALI PROGRAMLAMA*********/



using System;
using System.Windows.Forms;

namespace SavasOyunu
{
    public partial class AnaEkran : Form
    {
        public AnaEkran()
        {
            InitializeComponent();
        }

        private void AnaEkran_Load(object sender, EventArgs e)
        {

        }

        private void OyunaGirisButonu_Click(object sender, EventArgs e)
        {
            AnaForm anaform = new AnaForm();
            anaform.ShowDialog();
        }

        private void SkoraGirisButonu_Click(object sender, EventArgs e)
        {
            Skor_Ekranı skorEkran = new Skor_Ekranı();
            skorEkran.ShowDialog();
            
        }

        private void OyunBilgileri_Click(object sender, EventArgs e)
        {
            OyunBilgiEkrani oyunBilgi = new OyunBilgiEkrani();
            oyunBilgi.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
