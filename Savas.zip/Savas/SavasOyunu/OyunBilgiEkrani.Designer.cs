﻿
namespace SavasOyunu
{
    partial class OyunBilgiEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OyunBilgiEkrani));
            this.OyunBaslat = new System.Windows.Forms.Button();
            this.Bilgi = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OyunBaslat
            // 
            this.OyunBaslat.BackColor = System.Drawing.SystemColors.Desktop;
            this.OyunBaslat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.OyunBaslat.Font = new System.Drawing.Font("Kristen ITC", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OyunBaslat.Location = new System.Drawing.Point(0, 382);
            this.OyunBaslat.Name = "OyunBaslat";
            this.OyunBaslat.Size = new System.Drawing.Size(800, 68);
            this.OyunBaslat.TabIndex = 0;
            this.OyunBaslat.Text = "Oyuna Başlamak İçin Tıklayınız";
            this.OyunBaslat.UseVisualStyleBackColor = false;
            this.OyunBaslat.Click += new System.EventHandler(this.OyunBaslat_Click);
            // 
            // Bilgi
            // 
            this.Bilgi.AutoSize = true;
            this.Bilgi.Font = new System.Drawing.Font("Kristen ITC", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bilgi.Location = new System.Drawing.Point(80, 122);
            this.Bilgi.Name = "Bilgi";
            this.Bilgi.Size = new System.Drawing.Size(625, 135);
            this.Bilgi.TabIndex = 1;
            this.Bilgi.Text = "Oyunun Amacı Gelen Uçakları Vurmaktır.\r\n\r\nUçakları Vurmak İçin BOŞLUK Tuşuna Basi" +
    "niz.\r\n\r\nUçakSavarı Hareket Ettirmek İçin Yön Tuşlarını Kullanınız.\r\n";
            this.Bilgi.Click += new System.EventHandler(this.Bilgi_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Engravers MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(193, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(404, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "OYUN TAKIM BİLGİSİ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // OyunBilgiEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Bilgi);
            this.Controls.Add(this.OyunBaslat);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OyunBilgiEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OyunBilgiEkrani";
            this.Load += new System.EventHandler(this.OyunBilgiEkrani_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OyunBaslat;
        private System.Windows.Forms.Label Bilgi;
        private System.Windows.Forms.Label label1;
    }
}